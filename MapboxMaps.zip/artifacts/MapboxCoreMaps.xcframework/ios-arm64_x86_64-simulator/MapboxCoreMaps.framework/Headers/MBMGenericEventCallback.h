// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>

@class MBMGenericEvent;

/**
 * Generic event for experimental events.
 *
 * @see GenericEvent
 */
NS_SWIFT_NAME(GenericEventCallback)
typedef void (^MBMGenericEventCallback)(MBMGenericEvent * _Nonnull genericEvent); // NOLINT(modernize-use-using)
