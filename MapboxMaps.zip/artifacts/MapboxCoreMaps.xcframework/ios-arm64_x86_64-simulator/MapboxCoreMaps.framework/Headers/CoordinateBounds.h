// This file is generated and will be overwritten automatically.

#import "MBMCoordinateBounds.h"
