// This file is generated and will be overwritten automatically.

#import "MBMViewAnnotationPositionDescriptor.h"
