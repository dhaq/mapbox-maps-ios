// This file is generated and will be overwritten automatically.

#import "MBMPerformanceStatisticsOptions.h"
#import "MBMCumulativeRenderingStatistics.h"
#import "MBMDurationStatistics.h"
#import "MBMGroupPerformanceStatistics.h"
#import "MBMPerFrameRenderingStatistics.h"
#import "MBMPerformanceStatistics.h"
#import "MBMPerformanceStatisticsCallback.h"
