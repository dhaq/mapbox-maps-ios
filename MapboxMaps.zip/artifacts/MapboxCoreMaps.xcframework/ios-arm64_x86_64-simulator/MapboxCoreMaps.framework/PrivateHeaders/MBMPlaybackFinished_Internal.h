// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>

NS_SWIFT_NAME(PlaybackFinished)
typedef void (^MBMPlaybackFinished)(); // NOLINT(modernize-use-using)
