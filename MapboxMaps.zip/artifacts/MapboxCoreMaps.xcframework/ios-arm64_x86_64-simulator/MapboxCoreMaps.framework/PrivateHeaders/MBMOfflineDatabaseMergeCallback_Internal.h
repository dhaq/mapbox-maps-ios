// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
@class MBXExpected<__covariant Value, __covariant Error>;

@class MBMOfflineRegion;

NS_SWIFT_NAME(OfflineDatabaseMergeCallback)
__attribute__((deprecated))
typedef void (^MBMOfflineDatabaseMergeCallback)(MBXExpected<NSArray<MBMOfflineRegion *> *, NSString *> * _Nonnull regions); // NOLINT(modernize-use-using)
