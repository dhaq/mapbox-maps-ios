// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
@class MBXExpected<__covariant Value, __covariant Error>;

@class MBMFeatureExtensionValue;

NS_SWIFT_NAME(QueryFeatureExtensionCallback)
typedef void (^MBMQueryFeatureExtensionCallback)(MBXExpected<MBMFeatureExtensionValue *, NSString *> * _Nonnull extension); // NOLINT(modernize-use-using)
