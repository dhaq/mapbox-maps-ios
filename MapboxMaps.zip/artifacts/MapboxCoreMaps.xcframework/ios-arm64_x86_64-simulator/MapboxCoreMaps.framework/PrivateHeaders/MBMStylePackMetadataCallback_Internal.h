// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
@class MBXExpected<__covariant Value, __covariant Error>;

@class MBMStylePackError;

NS_SWIFT_NAME(StylePackMetadataCallback)
typedef void (^MBMStylePackMetadataCallback)(MBXExpected<id, MBMStylePackError *> * _Nonnull result); // NOLINT(modernize-use-using)
