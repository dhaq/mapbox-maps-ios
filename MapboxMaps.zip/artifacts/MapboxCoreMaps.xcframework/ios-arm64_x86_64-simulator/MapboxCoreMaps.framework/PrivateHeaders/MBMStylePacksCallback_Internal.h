// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
@class MBXExpected<__covariant Value, __covariant Error>;

@class MBMStylePack;
@class MBMStylePackError;

NS_SWIFT_NAME(StylePacksCallback)
typedef void (^MBMStylePacksCallback)(MBXExpected<NSArray<MBMStylePack *> *, MBMStylePackError *> * _Nonnull regions); // NOLINT(modernize-use-using)
