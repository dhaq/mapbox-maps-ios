// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
@class MBXExpected<__covariant Value, __covariant Error>;

@class MBMOfflineRegion;

NS_SWIFT_NAME(OfflineRegionCallback)
__attribute__((deprecated))
typedef void (^MBMOfflineRegionCallback)(MBXExpected<NSArray<MBMOfflineRegion *> *, NSString *> * _Nonnull regions); // NOLINT(modernize-use-using)
