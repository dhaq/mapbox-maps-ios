// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
@class MBXExpected<__covariant Value, __covariant Error>;

@class MBMMapSnapshot;

NS_SWIFT_NAME(SnapshotCompleteCallback)
typedef void (^MBMSnapshotCompleteCallback)(MBXExpected<MBMMapSnapshot *, NSString *> * _Nonnull snapshot); // NOLINT(modernize-use-using)
