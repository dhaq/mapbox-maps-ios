// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
@class MBXExpected<__covariant Value, __covariant Error>;

@class MBMStylePack;
@class MBMStylePackError;

NS_SWIFT_NAME(StylePackCallback)
typedef void (^MBMStylePackCallback)(MBXExpected<MBMStylePack *, MBMStylePackError *> * _Nonnull stylePack); // NOLINT(modernize-use-using)
