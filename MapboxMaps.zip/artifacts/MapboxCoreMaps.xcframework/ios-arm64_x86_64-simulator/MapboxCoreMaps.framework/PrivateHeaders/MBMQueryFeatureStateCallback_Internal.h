// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
@class MBXExpected<__covariant Value, __covariant Error>;

NS_SWIFT_NAME(QueryFeatureStateCallback)
typedef void (^MBMQueryFeatureStateCallback)(MBXExpected<id, NSString *> * _Nonnull stateMap); // NOLINT(modernize-use-using)
