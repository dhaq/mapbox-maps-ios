// This file is generated and will be overwritten automatically.

#import "MBMMapsResourceOptions_Internal.h"
