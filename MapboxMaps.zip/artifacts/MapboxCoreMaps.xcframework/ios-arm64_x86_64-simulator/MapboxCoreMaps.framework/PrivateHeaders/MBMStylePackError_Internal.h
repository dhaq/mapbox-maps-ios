// This file is generated and will be overwritten automatically.

#import <MapboxCoreMaps/MBMStylePackError.h>
#import <MapboxCoreMaps/MBMStylePackErrorType_Internal.h>

@interface MBMStylePackError ()
- (nonnull instancetype)initWithType:(MBMStylePackErrorType)type
                             message:(nonnull NSString *)message;
@property (nonatomic, readonly) MBMStylePackErrorType type;
@end
