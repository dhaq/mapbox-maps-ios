// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>

@class MBMStyleManager;

NS_SWIFT_NAME(StyleManagerCallback)
typedef void (^MBMStyleManagerCallback)(MBMStyleManager * _Nonnull styleManager); // NOLINT(modernize-use-using)
