// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
@class MBXExpected<__covariant Value, __covariant Error>;

@class MBMQueriedSourceFeature;

NS_SWIFT_NAME(QuerySourceFeaturesCallback)
typedef void (^MBMQuerySourceFeaturesCallback)(MBXExpected<NSArray<MBMQueriedSourceFeature *> *, NSString *> * _Nonnull features); // NOLINT(modernize-use-using)
