// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
@class MBXExpected<__covariant Value, __covariant Error>;

@class MBMQueriedRenderedFeature;

NS_SWIFT_NAME(QueryRenderedFeaturesCallback)
typedef void (^MBMQueryRenderedFeaturesCallback)(MBXExpected<NSArray<MBMQueriedRenderedFeature *> *, NSString *> * _Nonnull features); // NOLINT(modernize-use-using)
