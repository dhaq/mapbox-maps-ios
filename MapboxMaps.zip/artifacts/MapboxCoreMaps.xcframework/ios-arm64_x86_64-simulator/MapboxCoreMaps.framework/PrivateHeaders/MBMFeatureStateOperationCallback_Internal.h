// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
@class MBXExpected<__covariant Value, __covariant Error>;

NS_SWIFT_NAME(FeatureStateOperationCallback)
typedef void (^MBMFeatureStateOperationCallback)(MBXExpected<NSNull *, NSString *> * _Nonnull operationStatus); // NOLINT(modernize-use-using)
