// This file is generated and will be overwritten automatically.

#import <Foundation/Foundation.h>
@class MBXExpected<__covariant Value, __covariant Error>;

@class MBMOfflineRegion;

NS_SWIFT_NAME(OfflineRegionCreateCallback)
__attribute__((deprecated))
typedef void (^MBMOfflineRegionCreateCallback)(MBXExpected<MBMOfflineRegion *, NSString *> * _Nonnull region); // NOLINT(modernize-use-using)
